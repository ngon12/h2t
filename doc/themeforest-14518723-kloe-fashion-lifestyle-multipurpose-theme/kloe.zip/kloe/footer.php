<?php
kloe_qodef_get_footer();
?>