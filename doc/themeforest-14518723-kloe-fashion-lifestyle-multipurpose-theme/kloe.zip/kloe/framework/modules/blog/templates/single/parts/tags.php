<div class="qodef-single-tags-holder">
	<h5 class="qodef-single-tags-title"><?php esc_html_e('Tags:', 'kloe'); ?></h5>
	<div class="qodef-tags">
		<?php the_tags('', ',', ''); ?>
	</div>
</div>