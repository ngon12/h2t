<div class ="qodef-blog-share">
	<?php echo kloe_qodef_get_social_share_html(); ?>
</div>