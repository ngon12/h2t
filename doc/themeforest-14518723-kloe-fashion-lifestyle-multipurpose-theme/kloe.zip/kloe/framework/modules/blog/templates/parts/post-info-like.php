<div class="qodef-blog-like">
	<?php if( function_exists('kloe_qodef_get_like') ) kloe_qodef_get_like(); ?>
</div>