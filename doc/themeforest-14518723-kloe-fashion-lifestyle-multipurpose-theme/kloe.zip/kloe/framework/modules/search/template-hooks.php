<?php

//Get search HTML
add_action('kloe_qodef_before_page_header', 'kloe_qodef_get_search', 9);