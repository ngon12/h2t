<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/footer/options-map/map.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/footer/functions.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/footer/template-functions.php';
