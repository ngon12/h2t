<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/sidearea/options-map/map.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/sidearea/sidearea-functions.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/sidearea/custom-styles/sidearea.php';