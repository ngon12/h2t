<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tabs.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tab.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/custom-styles/custom-styles.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/options-map/map.php';
