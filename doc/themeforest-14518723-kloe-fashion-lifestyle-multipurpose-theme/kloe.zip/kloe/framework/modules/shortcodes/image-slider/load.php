<?php
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/image-slider/image-slider.php';