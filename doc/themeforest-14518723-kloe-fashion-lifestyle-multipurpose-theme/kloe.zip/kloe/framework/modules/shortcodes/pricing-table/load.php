<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/options-map/map.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/pricing-tables.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/pricing-table.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/custom-styles/pricing-table.php';