<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/message/message.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/message/custom-styles/message.php';