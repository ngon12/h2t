<?php
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion-tab.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/custom-styles/custom-styles.php';
require_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/options-map/map.php';
