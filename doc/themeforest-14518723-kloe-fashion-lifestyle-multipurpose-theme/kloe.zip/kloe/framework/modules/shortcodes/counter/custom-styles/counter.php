<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to kloe_qodef_style_dynamic hook
 */

//if (!function_exists('kloe_qodef_counter_style')) {
//
//	function kloe_qodef_counter_style()
//	{
//
//		if (kloe_qodef_options()->getOptionValue('option_value') !== '') {
//			echo kloe_qodef_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => kloe_qodef_filter_px(kloe_qodef_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('kloe_qodef_style_dynamic', 'kloe_qodef_counter_style');
//
//}

?>