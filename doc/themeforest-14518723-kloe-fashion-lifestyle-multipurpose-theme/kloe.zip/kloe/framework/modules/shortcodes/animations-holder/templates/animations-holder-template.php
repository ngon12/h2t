<div <?php kloe_qodef_class_attribute($class); ?> <?php echo kloe_qodef_get_inline_attrs($data); ?>>
	<div <?php kloe_qodef_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>