<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartpie/pie-chart-pie.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartpie/custom-styles/pie-chart-pie.php';