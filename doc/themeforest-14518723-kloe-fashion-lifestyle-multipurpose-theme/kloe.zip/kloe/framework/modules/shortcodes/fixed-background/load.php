<?php
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/fixed-background/fixed-background-holder.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/fixed-background/fixed-background-item.php';