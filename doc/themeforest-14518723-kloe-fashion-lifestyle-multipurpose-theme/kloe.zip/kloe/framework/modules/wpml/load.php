<?php

if (kloe_qodef_is_wpml_installed()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/wpml/wpml-functions.php';
}