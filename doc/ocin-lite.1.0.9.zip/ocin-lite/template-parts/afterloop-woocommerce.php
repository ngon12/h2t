					<div class="clearfix"></div>
					<?php
		            if ( ! is_shop() && ! is_product() && ! is_product_category() && ! is_product_tag() ) {
		                echo '</div><!-- /ql_background -->';
		            }
		            ?>
				
        	</div><!-- /content -->
